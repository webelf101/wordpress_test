<?php

$jobsearch_builder_shortcodes = array();

//
include plugin_dir_path(dirname(__FILE__)) . 'shortcode-builder/shortcodes/job-listings.php';
include plugin_dir_path(dirname(__FILE__)) . 'shortcode-builder/shortcodes/candidate-listings.php';
include plugin_dir_path(dirname(__FILE__)) . 'shortcode-builder/shortcodes/employer-listings.php';
include plugin_dir_path(dirname(__FILE__)) . 'shortcode-builder/shortcodes/job-categories.php';
include plugin_dir_path(dirname(__FILE__)) . 'shortcode-builder/shortcodes/packages.php';
include plugin_dir_path(dirname(__FILE__)) . 'shortcode-builder/shortcodes/login-registration.php';
include plugin_dir_path(dirname(__FILE__)) . 'shortcode-builder/shortcodes/post-new-job.php';
include plugin_dir_path(dirname(__FILE__)) . 'shortcode-builder/shortcodes/advance-search.php';
include plugin_dir_path(dirname(__FILE__)) . 'shortcode-builder/shortcodes/embeddable-jobs.php';