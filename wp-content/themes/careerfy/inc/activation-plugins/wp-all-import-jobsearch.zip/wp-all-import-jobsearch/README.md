# wp-all-import-example-addon
An example add-on for WP All Import. Use as a starting point to build your own add-ons.